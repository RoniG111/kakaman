let pacmanPixels = [
  [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
  [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
  [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
  [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
  [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0]
];

let inkyPixels = [
  [0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0],
  [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
  [0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1],
  [1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1],
  [1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1],
  [1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1],
  [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
  [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1]
];

let currentPixels = pacmanPixels;
let pixelSize = 10;
let grid = [];

function setup() {
  createCanvas(500, 500);
  noStroke();
  // Initialize grid with 1s
  for (let i = 0; i < width / pixelSize; i++) {
    grid[i] = [];
    for (let j = 0; j < height / pixelSize; j++) {
      grid[i][j] = 1;
    }
  }
}

function draw() {
  background(0);
  drawGrid();
  drawCharacter(mouseX, mouseY);
}

function drawGrid() {
  fill(255, 182, 193); // Light pink color
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid[i].length; j++) {
      if (grid[i][j] === 1) {
        let posX = i * 10;
        let posY = j * 10;
        rect(posX, posY, 10, 10);
      }
    }
  }
}

function drawCharacter(x, y) {
  fill(currentPixels === pacmanPixels ? color(255, 255, 0) : color(0, 255, 255)); // Pac-Man: Yellow, Inky: Cyan
  let cols = currentPixels[0].length;
  let rows = currentPixels.length;

  // Keep character within canvas boundaries
  x = constrain(x, cols / 2 * pixelSize, width - cols / 2 * pixelSize);
  y = constrain(y, rows / 2 * pixelSize, height - rows / 2 * pixelSize);

  // Eat the grid pixels
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      if (currentPixels[j][i] === 1) {
        let gridX = floor((x - cols / 2 * pixelSize) / pixelSize) + i;
        let gridY = floor((y - rows / 2 * pixelSize) / pixelSize) + j;
        if (grid[gridX] && grid[gridX][gridY] === 1) {
          grid[gridX][gridY] = 0;
        }
        rect(x + i * pixelSize - cols / 2 * pixelSize, y + j * pixelSize - rows / 2 * pixelSize, pixelSize, pixelSize);
      }
    }
  }
}

function mousePressed() {
  if (currentPixels === pacmanPixels) {
    currentPixels = inkyPixels;
  } else {
    currentPixels = pacmanPixels;
  }
}
